// SPDX-License-Identifier: Apache-2.0
// 
// Copyright 2008-2016 Conrad Sanderson (https://conradsanderson.id.au)
// Copyright 2008-2016 National ICT Australia (NICTA)
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// https://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ------------------------------------------------------------------------


//! \addtogroup Gen
//! @{


//! support class for generator functions (zeros, ones, eye)
template<typename T1, typename gen_type>
struct Gen
  : public Base< typename T1::elem_type, Gen<T1, gen_type> >
  {
  typedef typename T1::elem_type                   elem_type;
  typedef typename get_pod_type<elem_type>::result pod_type;
  
  static constexpr bool use_at    = (is_same_type<gen_type, gen_eye>::value);
  static constexpr bool is_simple = (is_same_type<gen_type, gen_ones>::value) || (is_same_type<gen_type, gen_zeros>::value);
  
  static constexpr bool is_row  = T1::is_row;
  static constexpr bool is_col  = T1::is_col;
  static constexpr bool is_xvec = T1::is_xvec;
  
  static constexpr bool has_subview = false;
  
  const uword n_rows;
  const uword n_cols;
  
  arma_inline  Gen(const uword in_n_rows, const uword in_n_cols);
  arma_inline ~Gen();
  
  arma_inline elem_type operator[] (const uword ii)               const;
  arma_inline elem_type at         (const uword r, const uword c) const;
  arma_inline elem_type at_alt     (const uword ii)               const;
  
  inline void apply              (Mat<elem_type>& out) const;
  inline void apply_inplace_plus (Mat<elem_type>& out) const;
  inline void apply_inplace_minus(Mat<elem_type>& out) const;
  inline void apply_inplace_schur(Mat<elem_type>& out) const;
  inline void apply_inplace_div  (Mat<elem_type>& out) const;
  
  inline void apply(subview<elem_type>& out) const;
  
  template<typename eT2>
  constexpr bool is_alias(const Mat<eT2>&) const { return false; }
  };



//! @}
