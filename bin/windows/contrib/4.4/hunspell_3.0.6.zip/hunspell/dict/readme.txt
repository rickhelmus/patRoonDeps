Dec 2018: Updated en_US / en_GB from
  https://extensions.libreoffice.org/extensions/english-dictionaries/2018-11.01