## Private future functions
as_function <- globals:::as_function
is_base_pkg <- globals:::is_base_pkg
is.base <- globals:::is.base
is_internal <- globals:::is_internal
where <- globals:::where
mdebug <- globals:::mdebug
envname <- globals:::envname
