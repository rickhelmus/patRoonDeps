# keys 0.1.1

* Added `global-bind` plugin which allows usage of hotkeys while `textInput` is active.

# keys 0.1.0

* Added a `NEWS.md` file to track changes to the package.
