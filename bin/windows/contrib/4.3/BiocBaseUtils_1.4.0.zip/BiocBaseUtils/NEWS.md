# Changes in version 1.4.0

## New features

* Added `isScalarLogical` for completeness; identical to `isTRUEorFALSE`.

# Changes in version 1.0.0

## New features

* Added a `NEWS.md` file to track changes to the package.
