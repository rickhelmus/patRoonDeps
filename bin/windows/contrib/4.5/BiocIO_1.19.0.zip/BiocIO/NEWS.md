# BiocIO 1.16.0

## Significant user-visible changes

* Add package anchors to links in documentation

## Bug fixes and minor improvements

* Use markdown for links and lists throughout the documentation

# BiocIO 1.14.0

* No significant changes.

# BiocIO 1.10.0

## Significant user-visible changes

* All the documentation has been updated to be more user-friendly.
