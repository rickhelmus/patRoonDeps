## ----style, echo = FALSE, results = 'asis', message=FALSE---------------------
BiocStyle::markdown()

## ----lib----------------------------------------------------------------------
library(PTMods)

## ----loaddata, echo = FALSE---------------------------------------------------
data(aminoacids)
data(modifications)
data(elements)

## ----install, eval = FALSE----------------------------------------------------
# if (!require("BiocManager", quietly = TRUE)) {
#     install.packages("BiocManager")
# }
# 
# BiocManager::install("PTMods")

## ----install2o, eval = FALSE--------------------------------------------------
# BiocManager::install("RforMassSpectrometry/PTMods")

## ----modifications------------------------------------------------------------
data(modifications)
head(modifications)

## ----aminoacids---------------------------------------------------------------
data(aminoacids)
head(aminoacids)

## ----elements-----------------------------------------------------------------
data(elements)
head(elements)

## ----convertAnnotion----------------------------------------------------------
convertAnnotation("M[Oxidation]PEPTIDE", convertToStyle = "deltaMass")
convertAnnotation("M[Oxidation]PEPTIDE", convertToStyle = "unimodId")
convertAnnotation("M[+15.995]PEPTIDE", convertToStyle = "name")

## ----basicAddMod--------------------------------------------------------------
addFixedModifications("MPEPTIDE",
    fixedModifications = c(M = "Oxidation")
)
addVariableModifications("MPEPTIDE",
    variableModifications = c(M = -15.995, T = "Phospho")
)

## ----Nterm--------------------------------------------------------------------
addFixedModifications("MPEPT[Phospho]IDE",
    fixedModifications = c(Nterm = 304)
)

## ----maxMods------------------------------------------------------------------
addVariableModifications("MPEPTIDE",
    variableModifications = c(M = -15.995, T = "Phospho"),
    maxMods = 1
)

## ----addMod-------------------------------------------------------------------
addModifications("MPEPTIDE",
    fixedModifications = c(M = "Oxidation"),
    variableModifications = c(T = 79.966),
    convertToStyle = "unimodId"
)

## ----getCanonicalSeq----------------------------------------------------------
getCanonicalSequence("[+304]-M[Oxidation]PEPT[UNIMOD:21]IDE")

## ----si-----------------------------------------------------------------------
sessionInfo()

