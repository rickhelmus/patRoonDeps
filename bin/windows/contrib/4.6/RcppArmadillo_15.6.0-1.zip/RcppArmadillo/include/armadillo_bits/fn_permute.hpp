// SPDX-License-Identifier: Apache-2.0
// 
// Copyright 2008-2016 Conrad Sanderson (https://conradsanderson.id.au)
// Copyright 2008-2016 National ICT Australia (NICTA)
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// https://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ------------------------------------------------------------------------


//! \addtogroup fn_permute
//! @{



template<typename T1>
arma_warn_unused
inline
const OpCube<T1, op_permute>
permute(const BaseCube<typename T1::elem_type, T1>& expr, const uword dim0_map, const uword dim1_map, const uword dim2_map)
  {
  arma_debug_sigprint();
  
  return OpCube<T1, op_permute>(expr.get_ref(), dim0_map, dim1_map, dim2_map);
  }



//! @}
