# v2.9

- Update to CDK 2.9 libraries.
- Removing a number of less-used jars prior to upload to CRAN. See the Makefile


# v2.8

- Update to CDK 2.8 libraries.

# v2.3

- Update to CDK 2.3. This features AtomContainer2 by default, new features for MassSpec, and a large number of bug fixes.

# v1.5.12

- Updated to the latest stable CDK release which features many improvements including the new Depiction module.

# v1.4.1

- Updated to latest stable CDK release (updates many atom types)

# v1.3.11

- Updated to latest stable CDK release

# v1.0

- Wrap CDK libs as a separate R package. Allows for faster development on theinterface package
