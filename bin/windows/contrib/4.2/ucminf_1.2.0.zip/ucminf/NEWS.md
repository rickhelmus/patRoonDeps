# ucminf 1.2.0

* Added a `NEWS.md` file to track changes to the package.

* Use of roxygen comments to generate package elements

* K Hervé Dakpo takes over package maintenance
