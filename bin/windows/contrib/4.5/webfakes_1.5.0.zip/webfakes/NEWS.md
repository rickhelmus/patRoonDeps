# webfakes 1.5.0

* New `keep_alive_timeout_ms` option in `server_opts()` to configure the
  idle timeout of keep-alive connections. The default is 5000 ms, up from
  the underlying CivetWeb default of 500 ms (#114).

* Handler functions may now declare a `locals` argument, in which case
  webfakes passes `app$locals` to it directly, without having to access
  it through `req$app$locals` (#112).

* webfakes now builds on platforms where `ar` does not writes a symbol
  index by default (@barracuda156, #121).

* webfakes now parses HTTP date headers (e.g. `Date`, `Last-Modified`,
  `Expires`) correctly regardless of the user's `LC_TIME` setting
  (@lbm364dl, #124).

* Route matching now ignores trailing slashes. Use regular expressions
  (`new_regexp()`) if you need exact trailing slash matching (#120).

* `httpbin_app()`'s `/post`, `/put`, `/patch`, `/delete` and `/anything*`
  endpoints now return the request body in the `data` field for any
  `Content-Type`, matching `httpbin.org` (#115).

# webfakes 1.4.1

No changes.

# webfakes 1.4.0

* webfakes now supports HTTPS (#110).

* The cleanup of a `new_app_process()` (and thus `local_app_process()`)
  is now faster. Instead of sending an interrupt first and waiting for
  the subprocess to quite, it is killed instantly.

# webfakes 1.3.2

* New server option: `decode_url`. If set to `FALSE`, then the web server
  will not URL-decode the URL (#106).

# webfakes 1.3.1

No changes.

# webfakes 1.3.0

* New `git_app()` app to fake a git HTTP server. See the webfakes test cases
  for examples.

* New `mw_cgi()` middleware to call CGI scripts. See the new `git_app()`
  for an example.

# webfakes 1.2.1

* `tmpl_glue()` now works correctly on platforms with an issue in
  `readChar(..., useBytes = TRUE)`, e.g. on macOS 14.x Sonoma:
  https://bugs.r-project.org/show_bug.cgi?id=18605.

# webfakes 1.2.0

* The httpbin app now implements the `/brotli`, `/deflate`, `/digest-auth`
  `/forms/post`, `/hidden-basic-auth`, `/range/:n`, `/stream/:n`, `/cache`
  and `/cache/:value` endpoints. With these, it implements all endpoint of
  the original Python httpbin app (#3).

* New middleware `mw_cookie_parser()` to parse a `Cookie` header. Relatedly,
  new `response$add_cookie()` and `response$clear_cookie()` methods to add a
  cookie to a response and to add a header that clears a cookie (#2).

* Parsing query parametes without a value now does not fail.

* New utility function `http_time_stamp()` to format a time stamp for HTTP.

* The httpbin app now implements the endpoints related to cookies (#3).

* The httpbin app now sends the `Date` header in the correct format.

* The `offset` parameter is now optional in the `/links` endpoint of the
  httpbin app.

* `mw_etag()` now does not add an `ETag` header to the response, if there
  is one already. (The comparision is case sensitive.)

* New middleware: `mw_range_parser()` to parse `Range` headers.

# webfakes 1.1.7

* No user visible changes.

# webfakes 1.1.6

* `response$send_file()` now handles `root = "/"` and absolute paths
  better on Windows.

* `new_app_process()` and `local_app_process()` are now faster,
  because the app object they need to copy to the subprocess is smaller.

# webfakes 1.1.5

* `mw_etag()` now handles the `If-None-Match` header properly, and sets
  the status code of the response to 304, and removes the response body.

# webfakes 1.1.4

* No user visible changes.

# webfakes 1.1.3

* webfakes now compiles on older macOS versions, hopefully really.

# webfakes 1.1.2

* webfakes now compiles on older macOS versions (before 10.12).

# 1.1.1

First release on CRAN
