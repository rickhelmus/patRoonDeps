This directory will contain a version of the rgl DLL that doesn't use OpenGL.

