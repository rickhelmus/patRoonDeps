# otelsdk 0.2.2

* No user visible changes.

# otelsdk 0.2.1

* otelsdk now compiles on macOS if `cmake` was installed from the installer
  and is not on the `PATH`.

* Documentation update for the new Otel 1.49.0 specification.
  The new `OTEL_ENTITIES` environment variable is not supported yet.

# otelsdk 0.2.0

First release on CRAN.
