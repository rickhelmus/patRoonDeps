## ----style, echo = FALSE, results = 'asis', message=FALSE---------------------
BiocStyle::markdown()

## ----setup, message = FALSE, echo = FALSE-------------------------------------
library("PSMatch")

## ----message = FALSE----------------------------------------------------------
spf <- MsDataHub::TMT_Erwinia_1uLSike_Top10HCD_isol2_45stepped_60min_01.20141210.mzML.gz()
library(Spectra)
sp <- Spectra(spf)

## -----------------------------------------------------------------------------
idf <- MsDataHub::TMT_Erwinia_1uLSike_Top10HCD_isol2_45stepped_60min_01.20141210.mzid()
id <- PSM(idf) |> filterPSMs()
id

## -----------------------------------------------------------------------------
sp <- joinSpectraData(sp, id, by.x = "spectrumId", by.y = "spectrumID")
sp

## -----------------------------------------------------------------------------
sp1158 <- filterPrecursorScan(sp, 1158)

## -----------------------------------------------------------------------------
plotSpectra(sp1158[1], xlim = c(400, 600))
abline(v = precursorMz(sp1158)[2], col = "red", lty = "dotted")

## -----------------------------------------------------------------------------
sp1158$sequence

## -----------------------------------------------------------------------------
calculateFragments(sp1158$sequence[2], addCarbamidomethyl = FALSE)

## -----------------------------------------------------------------------------
var_seq <- PTMods::addVariableModifications(sp1158$sequence[2],
    variableModifications = c(C = 57.02146, T = 79.966)
)

calculateFragments(var_seq)

## -----------------------------------------------------------------------------
plotSpectra(sp1158[2])

## -----------------------------------------------------------------------------
dataOrigin(sp1158)[2] <- "TMT_Erwinia" ## Reduces the mzspec text
plotSpectraPTM(sp1158[2],
    fixedModifications = c(C = "Carbamidomethyl")
)

## -----------------------------------------------------------------------------
plotSpectraPTM(sp1158[2],
    variableModifications = c(C = "Carbamidomethyl"),
    addCarbamidomethyl = FALSE, ## Remove carbamidomethyl by default
    asp = 1/2,
    deltaMz = FALSE,
    main = c("Scan 1158 without carbamidomethyl", "Scan 1158 with carbamidomethyl")
)

## ----si-----------------------------------------------------------------------
sessionInfo()

