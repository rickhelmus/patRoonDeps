
# rematch 2.0.0

* New `re_match_all` function to extract all matches.

* Removed the `perl` arguments, we always use PERL compatible regular
  expressions now.

# rematch 1.0.1

* Make `R CMD check` work when `testthat` is not available.

* Fixed a bug with group capture when `text` is a scalar.

# rematch 1.0.0

First public release.
