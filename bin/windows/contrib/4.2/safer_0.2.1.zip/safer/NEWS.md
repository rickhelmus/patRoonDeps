- safer(0.2.1)
  - encode_string gets a 'ascii' argument

- safer(0.2.0)
    - added 'asymmetric' encryption option

- safer (0.1.0) first release
