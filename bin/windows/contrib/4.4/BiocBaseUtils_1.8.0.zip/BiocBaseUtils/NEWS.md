# Changes in version 1.6.0

## New features

* `checkInstalled` allows to check if a package is installed and produces
copy-and-paste text for installation.

# Changes in version 1.4.0

## New features

* Added `isScalarLogical` for completeness; identical to `isTRUEorFALSE`.

# Changes in version 1.0.0

## New features

* Added a `NEWS.md` file to track changes to the package.
