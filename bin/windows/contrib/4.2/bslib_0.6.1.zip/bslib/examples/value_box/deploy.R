rsconnect::deployApp(
  rprojroot::find_package_root_file("inst/examples/value_box"),
  appName = "value_box",
  account = "bslib",
  forceUpdate = TRUE
)
