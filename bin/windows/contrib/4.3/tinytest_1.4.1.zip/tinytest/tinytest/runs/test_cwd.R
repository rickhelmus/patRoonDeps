report_side_effects()

old <- getwd()
setwd(tempdir())
setwd(old)

