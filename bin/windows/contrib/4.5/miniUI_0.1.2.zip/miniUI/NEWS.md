# miniUI 0.1.2

* Fixed incorrect links in the documentation.

# miniUI 0.1.1

* Initial release.
