# shinydisconnect 0.1.1 (2023-08-19)

Add correct package file documentation (see r-lib/roxygen2#1491)

# shinydisconnect 0.1.0 (2020-07-14)

Initial CRAN release
