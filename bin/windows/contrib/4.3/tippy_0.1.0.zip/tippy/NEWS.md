# tippy 0.1.0

Updated to tippy 3.2.0

- Deprecated `tippy_this` in favour of `with_tippy`.
