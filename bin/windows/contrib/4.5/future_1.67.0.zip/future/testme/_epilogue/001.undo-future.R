## Undo future debug
options(future.debug = FALSE)

## Undo future strategy
future::plan(oplan)
