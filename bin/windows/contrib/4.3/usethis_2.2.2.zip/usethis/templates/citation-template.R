bibentry(
  bibtype  = "Article",
  title    = ,
  author   = ,
  journal  = ,
  year     = ,
  volume   = ,
  number   = ,
  pages    = ,
  doi      =
)
