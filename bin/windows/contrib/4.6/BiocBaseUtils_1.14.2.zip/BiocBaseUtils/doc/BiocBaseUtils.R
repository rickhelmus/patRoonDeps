## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
    collapse = TRUE,
    comment = "#>"
)

## ----install, eval=FALSE------------------------------------------------------
# if (!requireNamespace("BiocManager", quietly = TRUE))
#     install.packages("BiocManager")
# BiocManager::install("BiocBaseUtils")

## ----load-package, include=TRUE, results="hide", message=FALSE, warning=FALSE----
library(BiocBaseUtils)

## ----assertions-logical-------------------------------------------------------
isTRUEorFALSE(TRUE)
isTRUEorFALSE(FALSE)
isTRUEorFALSE(NA, na.ok = TRUE)

## ----assertions-character-----------------------------------------------------
isScalarCharacter(LETTERS)
isScalarCharacter("L")
isCharacter(LETTERS)
isCharacter(NA_character_, na.ok = TRUE)
isZeroOneCharacter("")
isZeroOneCharacter("", zchar = TRUE)

## ----assertions-numeric-------------------------------------------------------
isScalarInteger(1L)
isScalarInteger(1)

isScalarNumber(1)
isScalarNumber(1:2)

## ----setslots-class-----------------------------------------------------------
setClass("A", representation = representation(slot1 = "numeric"))
aclass <- new("A", slot1 = 1:10)
aclass

## ----setslots-update----------------------------------------------------------
aclass <- setSlots(aclass, slot1 = 11:20)
aclass

## ----selectsome-show----------------------------------------------------------
setMethod("show", signature = "A", function(object) {
    s1info <- getElement(object, "slot1")
    cat("A sequence:", selectSome(s1info))
})
aclass

## ----session-info-------------------------------------------------------------
sessionInfo()

