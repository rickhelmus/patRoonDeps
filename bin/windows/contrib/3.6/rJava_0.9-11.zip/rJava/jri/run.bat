set PATH=%PATH%;D:/RCompile/recent/R\bin;D:/RCompile/recent/R\lib
c:/Progra~2/Java/JDK18~2.0_1/bin/java -cp .;examples;JRI.jar;src/JRI.jar rtest $*
